<div class="card" style="width: 18rem; margin-top: 15px ;margin-bottom: 15px;">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($carehome->name); ?></h5>
    <h8 class="card-subtitle mb-2 text-muted"><?php echo e($carehome->location->name); ?></h6>
    <p class="card-text"><?php echo e($carehome->number_beds); ?></p>
    <a href="<?php echo e(route('carehomes.show', $carehome->id)); ?>" class="card-link">Profile</a>
  </div>
</div>
<?php /**PATH C:\wamp64\www\carehomes-laravel\carehomes-laravel\resources\views/groups/widgets/carehomes.blade.php ENDPATH**/ ?>