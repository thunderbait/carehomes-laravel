

<?php $__env->startSection('title'); ?>
    <title>Edit Group</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div><br/>
        <?php endif; ?>

        <div class="container">
            <form method="POST" action="<?php echo e(route('groups.update', $group->id)); ?>">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="">Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $group->name)); ?>"/>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?php echo e(route('groups.show', $group->id)); ?>" class="btn btn-primary">Back</a>
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\carehomes-laravel\carehomes-laravel\resources\views/groups/edit.blade.php ENDPATH**/ ?>