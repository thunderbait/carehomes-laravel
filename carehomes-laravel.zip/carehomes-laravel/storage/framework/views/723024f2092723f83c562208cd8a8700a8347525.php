

<?php $__env->startSection('title'); ?>
    <title>Edit Carehome</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div><br/>
        <?php endif; ?>

        <div class="container">
            <form method="POST" action="<?php echo e(route('carehomes.update', $carehome->id)); ?>">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="">Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $carehome->name)); ?>"/>
                </div>

                <div class="form-group">
                    <label for="">Number of Beds</label>
                    <input type="text" class="form-control" name="number_beds"
                           value="<?php echo e($carehome->number_beds); ?>"/>
                </div>

                <div class="form-group">
                    <label for="">Location ID</label>
                    <input type="number" class="form-control" name="location_id"
                           value="<?php echo e($carehome->location_id); ?>"/>
                </div>

                <div class="form-group">
                    <label for="">Group ID</label>
                    <input type="number" class="form-control" name="group_id"
                           value="<?php echo e($carehome->group_id); ?>"/>
                </div>

                <div class="form-group">
                    <label for="">Notes</label>
                    <input type="text" class="form-control" name="notes" value="<?php echo e($carehome->notes); ?>"/>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?php echo e(route('carehomes.show', $carehome->id)); ?>" class="btn btn-primary">Back</a>
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\carehomes-laravel\carehomes-laravel\resources\views/carehomes/edit.blade.php ENDPATH**/ ?>