

<?php $__env->startSection('content'); ?>

    

    <div class="container">
        <div class="row">
        <div class="col-12">
            <?php if(session()->get('success')): ?>
                <div class="alert alert-success" style="text-align:center">
                    <?php echo e(session()->get('success')); ?>

                </div>
            <?php endif; ?>
        </div></div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/carehomes">Groups</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($group->name); ?></li>
            </ol>
        </nav>
    </div>
    <?php echo $__env->make('groups.widgets.jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  


    
    <div class="container">

        <h2>Carehomes</h2>

        <div class="row">
            <?php $__currentLoopData = $group->carehomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carehome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4 col-sm-12 col-md-4 col-xl-4">
                <?php echo $__env->make('groups.widgets.carehomes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\carehomes-laravel\carehomes-laravel\resources\views/groups/show.blade.php ENDPATH**/ ?>