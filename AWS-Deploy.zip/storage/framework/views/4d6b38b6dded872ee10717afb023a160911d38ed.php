

<?php $__env->startSection('content'); ?>

    <div class="container">

        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/home">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Advanced Filter</li>
          </ol>
        </nav>

        <h3>Advanced Carehome Filter</h3>
        <br>

        <div class="container">
        	<form action="/carehomes/search">
        		
        		<div class="form-row">
        			<!-- Input for Minimum Number of Beds -->
				    <div class="form-group col-md-4">
				      <label for="number_beds">Min. Number of Beds</label>
				      <input name="number_beds" id="number_beds" class="form-control" placeholder="Min. Number of Beds">
				    </div>
				</div>
				
				<div class="form-row">
					<!-- Input for Location Authority (Dropdown) -->
				    <div class="form-group col-md-4">
				      <label for="local_authority">Local Authority</label>
				      <select name="local_authority" id="local_authority" class="form-control" placeholder="Local Authority">
				      	<?php $__currentLoopData = $local_authorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local_authority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option selected><?php echo e($local_authority->name); ?></option>
				       	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
				    </div>					
				</div>

				<button type="submit" class="btn btn-primary">Submit</button>

        	</form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\carehomes-laravel\carehomes-laravel\resources\views/carehomes/filter.blade.php ENDPATH**/ ?>