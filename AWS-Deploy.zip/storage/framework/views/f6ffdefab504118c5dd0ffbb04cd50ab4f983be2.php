

<?php $__env->startSection('content'); ?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/carehomes">Carehomes</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($carehome->name); ?></li>
        </ol>
    </nav>
</div>

<?php echo $__env->make('carehomes.widgets.jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <h2>Carehome Notes</h2>
    <p><?php echo e($carehome->notes); ?></p>
    </br>
</div>

<div class="container">
    <div class="row">
        <?php $__currentLoopData = $carehome->contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-3">
            <?php echo $__env->make('carehomes.widgets.contacts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\carehomes-laravel\carehomes-laravel\resources\views/carehomes/show.blade.php ENDPATH**/ ?>