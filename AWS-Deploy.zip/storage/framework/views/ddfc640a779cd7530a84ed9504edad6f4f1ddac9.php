<!-- Contact Details -->
    <div class="card" style="width: 15rem;">
        <img class="card-img-top" src="https://www.kirkham-legal.co.uk/wp-content/uploads/2017/02/profile-placeholder.png" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($contact->name); ?></h5>
            <h8><?php echo e($contact->role); ?></h8><br>
            <h8><?php echo e($contact->email); ?></h8><br>
            <h8><?php echo e($contact->phone); ?></h8><br>
            <h8><?php echo e($contact->linkedin); ?></h8>
        </div>
    </div><?php /**PATH C:\wamp64\www\carehomes-laravel\carehomes-laravel\resources\views/carehomes/widgets/contacts.blade.php ENDPATH**/ ?>